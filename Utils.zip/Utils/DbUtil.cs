﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PMT.Utils
{
    public class DbUtil
    {
        private static String DATA_SOURCE = ConfigurationManager.AppSettings["DATA_SOURCE"];
        private static String DATA_BASE = ConfigurationManager.AppSettings["DATA_BASE"];
        private static String USER_NAME = ConfigurationManager.AppSettings["USER_NAME"];
        private static String PASSWORD = ConfigurationManager.AppSettings["PASSWORD"];
        private static String DATA_SOURCE_DW = ConfigurationManager.AppSettings["DATA_SOURCE_DW"];
        private static String DATA_BASE_DW = ConfigurationManager.AppSettings["DATA_BASE_DW"];
        private static String USER_NAME_DW = ConfigurationManager.AppSettings["USER_NAME_DW"];
        private static String PASSWORD_DW = ConfigurationManager.AppSettings["PASSWORD_DW"];
        public class Parameters : Dictionary<string, object> { }

        public static SqlConnection GetDBConnection()
        {
            string connString = @"Data Source=" + DATA_SOURCE + ";Initial Catalog="
                        + DATA_BASE + ";User ID=" + USER_NAME + ";Password=" + PASSWORD;

            SqlConnection conn = new SqlConnection(connString);

            return conn;
        }

        public static SqlConnection GetDBConnectionDw()
        {
            string connString = @"Data Source=" + DATA_SOURCE_DW + ";Initial Catalog="
                        + DATA_BASE_DW + ";User ID=" + USER_NAME_DW + ";Password=" + PASSWORD_DW;

            SqlConnection conn = new SqlConnection(connString); 

            return conn;
        }

        public static string GetDropDown(SqlConnection conn, string tableName, string textCol, string valueCol, bool isDistinct)
        {
            string distinctTerm = "";

            if (isDistinct)
            {
                distinctTerm = "distinct";
            }

            string query = String.Format("SELECT {0} {1} as Text, {2} as Value from {3} ORDER BY {1} ", distinctTerm, textCol, valueCol, tableName);

            using (conn)
            {
                conn.Open();

                SqlCommand command = new SqlCommand(query, conn);
                DbDataAdapter adapter = new SqlDataAdapter(command);
                DataTable result = new DataTable();

                adapter.Fill(result);
                conn.Close();

                return JsonConvert.SerializeObject(result);
            }
        }

        public static string GetDropDown(SqlConnection conn, string tableName, string textCol, string valueCol, bool isDistinct, bool isNullable)
        {
            string distinctTerm = "";
            if (isDistinct)
            {
                distinctTerm = "distinct";
            }
            string NullableTerm = "";
            if (!isNullable)
            {
                NullableTerm = string.Format("where {0} is not null OR {1} is not null", valueCol, textCol);
            }
            string query = String.Format("SELECT {0} {1} as Text, {2} as Value from {3} {4} ORDER BY {1} ", distinctTerm, textCol, valueCol, tableName, NullableTerm);

            using (conn)
            {
                conn.Open();

                SqlCommand command = new SqlCommand(query, conn);
                DbDataAdapter adapter = new SqlDataAdapter(command);
                DataTable result = new DataTable();

                adapter.Fill(result);
                conn.Close();

                return JsonConvert.SerializeObject(result);
            }
        }

        public static string GetResultSet(SqlConnection conn, string query)
        {
            string result = "";

            using (conn)
            {
                conn.Open();

                using (SqlCommand command = new SqlCommand(query, conn))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result += reader.GetString(1) + " " + reader.GetString(2) + "\n";
                    }
                }
            }

            return result;
        }

        public static DataTable getData(SqlConnection conn, string query, Parameters ParameterList)
        {
            DataTable info = new DataTable();
            using (conn)
            {
                conn.Open();

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    foreach (KeyValuePair<string, object> item in ParameterList)
                    {
                        command.Parameters.AddWithValue(item.Key, item.Value);
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(command))
                    {
                        da.Fill(info);
                    }
                }
            }
            return info;
        }
    }
}