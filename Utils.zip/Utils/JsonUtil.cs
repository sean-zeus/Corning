﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Script.Serialization;

namespace PMT.Utils
{
    public class JsonUtil
    {
        public static string GetValueByKey(string json, string key)
        {
            string userName = "";

            if (!string.IsNullOrEmpty(json))
            {
                userName = (string)JObject.Parse(json)[key];

                if (!string.IsNullOrEmpty(userName) && userName.Length > 2)
                {
                    userName = userName.Substring(0, userName.Length);
                }
            }

            return userName;
        }

        public static string GetJsonValueByName(string json, string name)
        {
            return (string)JArray.Parse(json).Children()[name].First();
        }

        public static DataTable ToDataTable(string json)
        {
            return (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
        }

        public static string TableToJson(DataTable dt)
        {
            List<object> dic = new List<object>();

            foreach (DataRow dr in dt.Rows)
            {
                Dictionary<string, object> result = new Dictionary<string, object>();

                foreach (DataColumn dc in dt.Columns)
                {
                    result.Add(dc.ColumnName, dr[dc].ToString());
                }

                dic.Add(result);
            }

            JavaScriptSerializer serialize = new JavaScriptSerializer();

            return serialize.Serialize(dic);
        }

        public static List<string> GetAllColumns(string jsonStr, string colName)
        {
            List<string> result = new List<string>();
            var objects = JArray.Parse(jsonStr);

            foreach (JObject root in objects)
            {
                foreach (KeyValuePair<string, JToken> col in root)
                {
                    var cName = col.Key;

                    if (cName == colName)
                    {
                        result.Add((string)col.Value);
                    }
                }
            }

            return result;
        }

        public static List<string> GetAllColumns(string jsonStr)
        {
            List<string> result = new List<string>();
            var objects = JArray.Parse(jsonStr);

            foreach (JObject root in objects)
            {
                foreach (KeyValuePair<string, JToken> col in root)
                {
                    result.Add((string)col.Value);
                }
            }

            return result;
        }
    }
}