﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Mvc;

namespace PMT.Utils
{
    public class FileUtil
    {
        public static readonly string REMOTE_COA_PATH = ConfigurationManager.AppSettings["REMOTE_COA_PATH"];
        public static readonly string REMOTE_USER_NAME = ConfigurationManager.AppSettings["REMOTE_USER_NAME"];
        public static readonly string REMOTE_PASSWORD = ConfigurationManager.AppSettings["REMOTE_PASSWORD"];

        public static void Delete(string path, string fileName)
        {
            string[] fileList = System.IO.Directory.GetFiles(path, fileName);

            foreach (string file in fileList)
            {
                System.Diagnostics.Debug.WriteLine(file + "will be deleted");
                System.IO.File.Delete(file);
            }
        }

        public static bool IsExisted(string path, string fileName)
        {
            string[] fileList = System.IO.Directory.GetFiles(path, fileName);

            return fileList.Length > 0;
        }

        public static void Rename(string path, string oldName, string newName)
        {
            string[] fileList = System.IO.Directory.GetFiles(path, oldName);
            string existedFileName = fileList[0]; //only one uploaded file
            string prefix = newName.Substring(0, 1);
            int index = existedFileName.LastIndexOf("/");
            StringBuilder sb = new StringBuilder(existedFileName);

            sb[index + 1] = char.Parse(prefix);

            string updateFileName = sb.ToString();

            System.IO.File.Move(existedFileName, updateFileName);
        }

        public static List<string> GetLocalFileNames(string path, string extension)
        {
            List<string> allFileNames = new List<string>();

            foreach (string fileName in Directory.GetFiles(path, extension).Select(Path.GetFileName))
            {
                allFileNames.Add(fileName);
            }

            return allFileNames;
        }

        public static Dictionary<string, DateTime> GetRemoteFileNamesNCreationDate(string path, string extension)
        {
            Dictionary<string, DateTime> allFiles = new Dictionary<string, DateTime>();
            NetworkCredential credentials = new NetworkCredential(REMOTE_USER_NAME, REMOTE_PASSWORD);
            //NetworkCredential credentials = new NetworkCredential(@"NA\IMSK8AppPrd", "#0(UgsHdc5!^2GgT");

            using (new NetworkConnection(path, credentials))
            {
                string[] Remotefiles = Directory.GetFiles(path, extension);

                for (int i = 0; i <= Remotefiles.Length - 1; i++)
                {
                    string fileName = Path.GetFileName(Remotefiles[i]);
                    DateTime creationDate = File.GetCreationTime(path + "\\" + fileName);

                    allFiles.Add(fileName, creationDate);
                }
            }

            return allFiles;
        }

        public static DateTime GetCreationTime(string dirPath, string fileName)
        {
            NetworkCredential credentials = new NetworkCredential(REMOTE_USER_NAME, REMOTE_PASSWORD);
            DateTime creationTime = DateTime.Now;

            using (new NetworkConnection(dirPath, credentials))
            {
                creationTime = File.GetCreationTime(dirPath + "\\" + fileName);
            }

            return creationTime;
        }

        public static void MoveFile(string sourceFile, string destFile)
        {
            NetworkCredential credentials = new NetworkCredential(REMOTE_USER_NAME, REMOTE_PASSWORD);
            DateTime creationTime = DateTime.Now;

            using (new NetworkConnection(REMOTE_COA_PATH, credentials))
            {
                File.Copy(sourceFile, destFile, true);
                File.Delete(sourceFile);
            }
        }

        public static void CopyFile(string sourceFile, string destFile)
        {
            NetworkCredential credentials = new NetworkCredential(REMOTE_USER_NAME, REMOTE_PASSWORD);

            using (new NetworkConnection(REMOTE_COA_PATH, credentials))
            {
                //if (Directory.Exists(sourceFile) && Directory.Exists(destFile))
                //if (Directory.Exists(sourceFile))
                //{
                File.Copy(sourceFile, destFile, true);
                //}
            }
        }
    }

    public class NetworkConnection : IDisposable
    {
        readonly string _networkName;

        public NetworkConnection(string networkName, NetworkCredential credentials)
        {
            _networkName = networkName;

            var netResource = new NetResource
            {
                Scope = ResourceScope.GlobalNetwork,
                ResourceType = ResourceType.Disk,
                DisplayType = ResourceDisplaytype.Share,
                RemoteName = networkName
            };

            var userName = string.IsNullOrEmpty(credentials.Domain)
                ? credentials.UserName
                : string.Format(@"{0}\{1}", credentials.Domain, credentials.UserName);

            var result = WNetAddConnection2(
                netResource,
                credentials.Password,
                userName,
                0);

            if (result != 0)
            {
                throw new Win32Exception(result, "Error connecting to remote share Code:" + result);
            }
        }

        ~NetworkConnection()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            WNetCancelConnection2(_networkName, 0, true);
        }

        [DllImport("mpr.dll")]
        private static extern int WNetAddConnection2(NetResource netResource,
            string password, string username, int flags);

        [DllImport("mpr.dll")]
        private static extern int WNetCancelConnection2(string name, int flags,
            bool force);

        [StructLayout(LayoutKind.Sequential)]
        public class NetResource
        {
            public ResourceScope Scope;
            public ResourceType ResourceType;
            public ResourceDisplaytype DisplayType;
            public int Usage;
            public string LocalName;
            public string RemoteName;
            public string Comment;
            public string Provider;
        }

        public enum ResourceScope : int
        {
            Connected = 1,
            GlobalNetwork,
            Remembered,
            Recent,
            Context
        };

        public enum ResourceType : int
        {
            Any = 0,
            Disk = 1,
            Print = 2,
            Reserved = 8,
        }

        public enum ResourceDisplaytype : int
        {
            Generic = 0x0,
            Domain = 0x01,
            Server = 0x02,
            Share = 0x03,
            File = 0x04,
            Group = 0x05,
            Network = 0x06,
            Root = 0x07,
            Shareadmin = 0x08,
            Directory = 0x09,
            Tree = 0x0a,
            Ndscontainer = 0x0b
        }
    }
}