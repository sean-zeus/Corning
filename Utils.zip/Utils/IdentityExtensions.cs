﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;

namespace PMT.Utils
{
    public static class IdentityExtensions
    {
        public static int GetPermission(this IIdentity identity)
        {
            if (identity == null)
            {
                throw new ArgumentNullException("identity");
            }

            var ci = identity as ClaimsIdentity;

            if (ci != null)
            {
                string permissionStr = "0";

                if (ci.FindFirst("Permission") != null) {
                    permissionStr = ci.FindFirst("Permission").ToString().Substring(("Permission: ".Length));
                }
                
                int permissionValue = Convert.ToInt32(permissionStr);

                //if first time login, clear permission
                if (ci.FindFirst("IsFirstLogin") != null)
                {
                    if (Convert.ToBoolean(ci.FindFirst("IsFirstLogin").Value))
                    {
                        permissionValue = 0;
                    }
                }

                return permissionValue;
            }

            return 0;
        }

        public static bool IsFirstLogin(this IIdentity identity)
        {
            bool ReturnValue = true;

            if (identity == null)
            {
                throw new ArgumentNullException("identity");
            }

            var ci = identity as ClaimsIdentity;

            if (ci != null)
            {
                try
                {
                    if (ci.FindFirst("IsFirstLogin") != null)
                    {
                        ReturnValue = Convert.ToBoolean(ci.FindFirst("IsFirstLogin").Value);
                    }
                }
                catch
                {
                    ReturnValue = true;
                }

            }

            return ReturnValue;
        }

        public static bool IsAccountEnable(this IIdentity identity)
        {
            bool ReturnValue = true;

            if (identity == null)
            {
                throw new ArgumentNullException("identity");
            }

            var ci = identity as ClaimsIdentity;

            if (ci != null)
            {
                try
                {
                    ReturnValue = Convert.ToBoolean(ci.FindFirst("IsAccountEnable").Value);
                }
                catch
                {
                    ReturnValue = true;
                }

            }

            return ReturnValue;
        }
    }
}