﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;

namespace PMT.Utils
{
    public class WebServiceUtil
    {
        public static string GetResponse(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.UTF8);

                    return TrimJson(reader.ReadToEnd());
                }
            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                    // log errorText
                }
                throw;
            }
        }

        public static string PostResponse(string url, string[] postData)
        {
            try
            {
                string Result = string.Empty;
                HttpClient client = new HttpClient();
                HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, url);
                requestMessage.Content = new StringContent(JsonConvert.SerializeObject(postData), System.Text.Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.SendAsync(requestMessage).GetAwaiter().GetResult();

                if (response.StatusCode.ToString() == "OK")
                {

                    return TrimJson(response.Content.ReadAsStringAsync().Result);

                }
                else
                {
                    return "server connect error";
                }



            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                    // log errorText
                }
                throw;
            }
        }
        private static string TrimJson(string json)
        {
            json = json.Replace("\\", string.Empty);
            json = json.Trim('"');

            return json;
        }

        public static string arrayToStrParam(string paramName, string[] paramArray)
        {
            string parameterStr = "";

            for (int i = 0; i < paramArray.Length; i++)
            {
                parameterStr += paramName + "=" + paramArray[i] + "&";
            }

            return parameterStr;
        }
    }
}