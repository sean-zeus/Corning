﻿using PMT.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace PMT.Utils
{
    public class CommonUtil
    {
        public static IEnumerable<SelectListItem> ListToSelect(List<string> list)
        {
            List<SelectListItem> item = list.ConvertAll(a =>
            {
                return new SelectListItem()
                {
                    Text = a.ToString(),
                    Value = a.ToString(),
                    Selected = false
                };
            });

            return null;
        }

        public static DataTable ListToDataTable<T>(List<T> list)
        {
            Type type = typeof(T);
            PropertyInfo[] proInfo = type.GetProperties();
            DataTable dt = new DataTable();

            foreach (PropertyInfo p in proInfo)
            {
                Type t = p.PropertyType;

                if (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    t = t.GetGenericArguments()[0];
                }

                dt.Columns.Add(p.Name, t);
            }
            foreach (T t in list)
            {
                DataRow dr = dt.NewRow();

                foreach (PropertyInfo p in proInfo)
                {
                    object obj = p.GetValue(t);

                    if (obj == null) continue;

                    if (p.PropertyType == typeof(DateTime) && Convert.ToDateTime(obj) < Convert.ToDateTime("1753-01-01"))
                    {
                        continue;
                    }

                    dr[p.Name] = obj;
                }

                dt.Rows.Add(dr);
            }

            return dt;
        }

        //public static DataTable ListToDataTable<T>(IEnumerable<T> collection)
        //{
        //    var props = typeof(T).GetProperties();
        //    var dt = new DataTable();

        //    dt.Columns.AddRange(props.Select(p => new DataColumn(p.Name, p.PropertyType)).ToArray());

        //    if (collection.Count() > 0)
        //    {
        //        for (int i = 0; i < collection.Count(); i++)
        //        {
        //            ArrayList tempList = new ArrayList();

        //            foreach (PropertyInfo pi in props)
        //            {
        //                object obj = pi.GetValue(collection.ElementAt(i), null);
        //                tempList.Add(obj);
        //            }

        //            object[] array = tempList.ToArray();

        //            dt.LoadDataRow(array, true);
        //        }
        //    }
        //    return dt;
        //}

        public static List<string> GetObjectProperty(Object obj)
        {
            string objName = obj.GetType().Name;
            List<string> allProperities = new List<string>();

            if (objName.Equals("UserLog"))
            {
                obj = (UserLog)obj;
            }

            Type myType = obj.GetType();
            IList<PropertyInfo> props = new List<PropertyInfo>(myType.GetProperties());

            foreach (PropertyInfo prop in props)
            {
                allProperities.Add(prop.Name);
                //object propValue = prop.GetValue(obj, null);
            }

            return allProperities;
        }


        public static bool IsNumeric(string str)
        {
            int value = 0;

            return int.TryParse(str, out value);
        }

        public static string RemoveSpace(string str)
        {
            return Regex.Replace(str, @"\s+", "");
        }
    }
}