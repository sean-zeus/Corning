﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;
using System.Net;
using System.Text;
using System.Net.Mime;
using System.Text.RegularExpressions;

namespace PMT.Utils
{
    public class EmailUtil
    {
        internal static string SMTP_HostName = "smtphub.corning.com";
        internal static int SMTP_HostPort = 25;
        internal static bool UseCredentials = false;
        internal static string CredentialUserName = "";
        internal static string CredentialUserPassword = "";
        //internal static string MailMessageCcAddress="";
        internal static string MailMessageBccAddress = "";
        internal static bool IsBodyHtml = true;
        internal static bool UseBodyHtmlDefaultFont = true;
        //internal static string mailMessageFromAddress = "GSACSMINTFC@corning.com";
        //internal static string[] attachedFiles = null;

        public static bool IsMailList(string emailList)  
        {
            string pattern = @"^([a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])(;)?)+$";

            Regex regex = new Regex(pattern);
            Match match = regex.Match(emailList);

            return match.Success;          
        }

        public static void SendEmail(string mailMessageFromAddress, string mailMessageToAddress, string mailMessageCcAddress,
                                       string mailMessageSubject, string mailMessageBody, string[] attachedFiles)
        {
            SmtpClient smtpClientEmail = new SmtpClient(SMTP_HostName, SMTP_HostPort);
            if (UseCredentials) smtpClientEmail.Credentials = new NetworkCredential(CredentialUserName, CredentialUserPassword);

            MailMessage eMailMessage = new MailMessage();
            eMailMessage.From = new MailAddress(mailMessageFromAddress);

            string[] emailAddressList;

            emailAddressList = mailMessageToAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
            foreach (string mailAddress in emailAddressList) { eMailMessage.To.Add(mailAddress); }

            emailAddressList = mailMessageCcAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
            foreach (string mailAddress in emailAddressList) { eMailMessage.CC.Add(mailAddress); }

            emailAddressList = MailMessageBccAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
            foreach (string mailAddress in emailAddressList) { eMailMessage.Bcc.Add(mailAddress); }

            eMailMessage.SubjectEncoding = Encoding.UTF8;
            eMailMessage.Subject = mailMessageSubject;

            eMailMessage.BodyEncoding = Encoding.UTF8;
            eMailMessage.IsBodyHtml = IsBodyHtml;
            if ((IsBodyHtml) && (UseBodyHtmlDefaultFont))
                eMailMessage.Body = string.Format("<font face=\"Calibri\" style='font-size:11pt;'>{0}{1}{0}{2}</font>",
                                                "<br>",
                                                "",
                                                mailMessageBody.Replace((((char)13).ToString() + ((char)10).ToString()), "<br>").Replace(((char)13).ToString(), "<br>").Replace(((char)10).ToString(), "<br>").Replace(" ", "&nbsp;"));
            else if (IsBodyHtml)
                eMailMessage.Body = (mailMessageBody.Replace((((char)13).ToString() + ((char)10).ToString()), "<br>").Replace(((char)13).ToString(), "<br>").Replace(((char)10).ToString(), "<br>").Replace(" ", "&nbsp;"));
            else
                eMailMessage.Body = ((((char)13).ToString() + ((char)10).ToString()) + mailMessageBody.Replace((((char)13).ToString() + ((char)10).ToString()), "<br>").Replace(((char)13).ToString(), "<br>").Replace(((char)10).ToString(), "<br>").Replace(" ", "&nbsp;"));

            if ((attachedFiles != null) && (attachedFiles.Length > 0))
            {
                Attachment[] attachments = new Attachment[attachedFiles.Length];
                for (int index = 0; index < attachedFiles.Length; index++)
                {
                    attachments[index] = new Attachment(attachedFiles[index], MediaTypeNames.Application.Octet);
                    attachments[index].ContentType.CharSet = "UTF-8";
                    attachments[index].Name = attachedFiles[index].Split('/').Last();
                    eMailMessage.Attachments.Add(attachments[index]);
                }
            }

            smtpClientEmail.Send(eMailMessage);
        }
        public static void SendEmail(string mailMessageFromAddress, string mailMessageToAddress, string mailMessageCcAddress,
                                       string mailMessageSubject, string mailMessageBody)
        {
            SmtpClient smtpClientEmail = new SmtpClient(SMTP_HostName, SMTP_HostPort);
            if (UseCredentials) smtpClientEmail.Credentials = new NetworkCredential(CredentialUserName, CredentialUserPassword);

            MailMessage mail = new MailMessage();

            try
            {
   
                mail.From = new MailAddress(mailMessageFromAddress);
                string[] emailAddressList;

                emailAddressList = mailMessageToAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
                foreach (string mailAddress in emailAddressList) { mail.To.Add(mailAddress); }

                emailAddressList = mailMessageCcAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
                foreach (string mailAddress in emailAddressList) { mail.CC.Add(mailAddress); }

                emailAddressList = MailMessageBccAddress.Split((new Char[] { ';', ',' }), StringSplitOptions.RemoveEmptyEntries);
                foreach (string mailAddress in emailAddressList) { mail.Bcc.Add(mailAddress); }

                mail.Subject = mailMessageSubject;
                mail.IsBodyHtml = true;
                mail.Body = mailMessageBody.Replace("\n", "<br/>");
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnSuccess;
                smtpClientEmail.Send(mail);
            }
            catch (Exception ex)
            {
                
            }
        }

    }
}