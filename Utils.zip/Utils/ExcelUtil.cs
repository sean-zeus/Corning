﻿using Microsoft.AspNet.Identity;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;

namespace PMT.Utils
{
    public class ExcelUtil
    {
        private static readonly string DOWNLOAD_PATH = ConfigurationManager.AppSettings["FILE_DOWNLOAD"];

        public static string SaveToFolder(HttpPostedFileBase file)
        {
            string filename = file.FileName;
            string userID = (HttpContext.Current.User.Identity.GetUserId()) ?? "";
            string path = Path.Combine(DOWNLOAD_PATH, userID + filename);
            var fileExt = Path.GetExtension(filename);

            if (file.ContentLength > 0)
            {
                Directory.Exists(path);
            }

            file.SaveAs(path);

            return filename;
        }

        public static Stream getFile(string FileName)
        {
            Stream FileByte = new FileStream(DOWNLOAD_PATH + FileName, FileMode.Open, FileAccess.Read, FileShare.Read);

            return FileByte;
        }

        public static DataTable toDataTable(Object obj)
        {
            DataTable dt = new DataTable();
            int headerRow = 0;

            try
            {
                IWorkbook workbook = null;

                if (obj.GetType() == typeof(HSSFWorkbook))
                {
                    workbook = (HSSFWorkbook)obj;
                }
                else if (obj.GetType() == typeof(XSSFWorkbook))
                {
                    workbook = (XSSFWorkbook)obj;
                }

                ISheet sheet = workbook.GetSheetAt(0);
                IRow row;

                row = sheet.GetRow(headerRow);

                if (row != null)
                {
                    for (int m = 0; m < row.LastCellNum; m++)
                    {
                        string cellValue = row.GetCell(m).ToString();

                        dt.Columns.Add(cellValue);
                    }
                }

                for (int i = headerRow + 1; i <= sheet.LastRowNum; i++)
                {
                    DataRow dr = dt.NewRow();

                    row = sheet.GetRow(i);

                    if (row != null)
                    {
                        for (int j = 0; j < row.LastCellNum; j++)
                        {
                            ICell cell = row.GetCell(j);

                            if (cell != null)
                            {
                                switch (cell.CellType)
                                {
                                    case CellType.Numeric:
                                        dr[j] = (DateUtil.IsCellDateFormatted(cell)) ? cell.DateCellValue.ToString() : cell.NumericCellValue.ToString();
                                        break;
                                    case CellType.Formula:
                                        //dr[j] = cell.CellFormula; 
                                        dr[j] = cell.NumericCellValue;
                                        break;
                                    default:
                                        dr[j] = cell.StringCellValue;
                                        break;
                                }
                            }
                        }
                    }

                    dt.Rows.Add(dr);
                }

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable toDataTable(String fileName, int headerRow = 0)
        {
            DataTable dt = new DataTable();
            try
            {
                IWorkbook workbook = null;
                XSSFFormulaEvaluator eval = null;
                FileStream fileStream = new FileStream(DOWNLOAD_PATH + HttpContext.Current.User.Identity.GetUserId() + fileName, FileMode.Open, FileAccess.Read);

                if (fileName.IndexOf(".xlsx") > 0)
                {
                    workbook = new XSSFWorkbook(fileStream);
                    eval = new XSSFFormulaEvaluator((XSSFWorkbook)workbook);
                }
                else if (fileName.IndexOf(".xls") > 0)
                {
                    workbook = new HSSFWorkbook(fileStream);
                    eval = new XSSFFormulaEvaluator((HSSFWorkbook)workbook);
                }
                ISheet sheet = workbook.GetSheetAt(0);
                sheet.ForceFormulaRecalculation = true;

                IRow row;
                ICell cell;
                row = sheet.GetRow(headerRow);

                if (row != null)
                {
                    for (int m = 0; m < row.LastCellNum; m++)
                    {
                        cell = row.GetCell(m);
                        if (cell.CellType == CellType.Blank)
                        {
                            break;
                        }
                        string cellValue = row.GetCell(m).ToString();
                        dt.Columns.Add(cellValue);
                    }
                }

                for (int i = headerRow + 1; i <= sheet.LastRowNum; i++)
                {
                    DataRow dr = dt.NewRow();
                    row = sheet.GetRow(i);
                    if (row != null)
                    {
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            cell = row.GetCell(j);
                            if (cell != null)
                            {
                                if (cell.CellType == CellType.Formula)
                                {
                                    eval.EvaluateFormulaCell(cell);
                                }

                                dr[j] = GetCellValues(cell, cell.CellType);
                            }
                        }
                    }

                    dt.Rows.Add(dr);
                }

                fileStream.Close();

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static object GetCellValues(ICell cell, CellType cellType)
        {
            switch (cellType)
            {
                case CellType.Numeric:
                    if (DateUtil.IsCellDateFormatted(cell))
                    {
                        return cell.DateCellValue;
                    }
                    else
                    {
                        return cell.NumericCellValue;
                    }
                case CellType.Formula:
                    return GetCellValues(cell, cell.CachedFormulaResultType);
                case CellType.Boolean:
                    return cell.BooleanCellValue;
                case CellType.Blank:
                    return null;
                case CellType.String:
                    return cell.RichStringCellValue;
                case CellType.Error:
                case CellType.Unknown:
                default:
                    return cell.StringCellValue;
            }
        }

        public static string ExportToExcel(DataTable dt, string fileName)
        {
            string path = DOWNLOAD_PATH + fileName;
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = (XSSFSheet)workbook.CreateSheet("Sheet1");
            IRow row = sheet.CreateRow(0);
            XSSFCellStyle cellStyle = (XSSFCellStyle)workbook.CreateCellStyle();

            cellStyle.FillForegroundColor = IndexedColors.RoyalBlue.Index;
            cellStyle.FillPattern = FillPattern.SolidForeground;

            var fontColor = new XSSFColor(new byte[] { 255, 255, 255 });
            var font = (XSSFFont)workbook.CreateFont();

            font.SetColor(fontColor);
            cellStyle.SetFont(font);

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = row.CreateCell(i);

                cell.SetCellValue(dt.Columns[i].ColumnName);
                cell.CellStyle = cellStyle;
                sheet.AutoSizeColumn(i);
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row1 = sheet.CreateRow(i + 1);

                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    ICell cell = row1.CreateCell(j);

                    //cell.SetCellType(GetCorrectCellType(dt.Rows[i][j].GetType()));
                    cell.SetCellValue(dt.Rows[i][j].ToString());
                }
            }

            using (FileStream file = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                workbook.Write(file);
                file.Close();
            }

            return fileName;
        }

        public static string ExportToExcel(DataTable dt, string fileName, int[] numericArray)
        {
            string path = DOWNLOAD_PATH + fileName;
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = (XSSFSheet)workbook.CreateSheet("Sheet1");
            IRow row = sheet.CreateRow(0);
            XSSFCellStyle cellStyle = (XSSFCellStyle)workbook.CreateCellStyle();

            cellStyle.FillForegroundColor = IndexedColors.RoyalBlue.Index;
            cellStyle.FillPattern = FillPattern.SolidForeground;

            var fontColor = new XSSFColor(new byte[] { 255, 255, 255 });
            var font = (XSSFFont)workbook.CreateFont();

            font.SetColor(fontColor);
            cellStyle.SetFont(font);

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = row.CreateCell(i);

                cell.SetCellValue(dt.Columns[i].ColumnName);
                cell.CellStyle = cellStyle;
                sheet.AutoSizeColumn(i);
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row1 = sheet.CreateRow(i + 1);

                for (int j = 0; j < dt.Columns.Count; j++)
                { 
                    ICell cell = row1.CreateCell(j);

                    cell.SetCellValue(dt.Rows[i][j].ToString());

                    //if (Array.Exists(numericArray, e => e == j))
                    //{
                    //    cell.SetCellType(CellType.Numeric);
                    //}

                    if (Array.Exists(numericArray, e => e == j))
                    {
                        var strValToBeConverted = cell.StringCellValue;
                        cell.SetCellType(CellType.Numeric);
                        int intVal = -1;
                        int.TryParse(strValToBeConverted, out intVal);
                        cell.SetCellValue(intVal);
                    }
                }
            }

            using (FileStream file = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                workbook.Write(file);
                file.Close();
            }

            return fileName;
        }

        private static CellType GetCorrectCellType(Type dataType)
        {
            if (dataType == typeof(string))
            {
                return CellType.String;
            }
            else if (dataType == typeof(int) || dataType == typeof(double))
            {
                return CellType.Numeric;
            }
            else if (dataType == typeof(bool))
            {
                return CellType.Boolean;
            }
            else
            {
                return CellType.Blank;
                //return CellType.Unknown; 
            }
        }

        public static void Delete(string fileName)
        {
            if (FileUtil.IsExisted(DOWNLOAD_PATH, fileName))
            {
                FileUtil.Delete(DOWNLOAD_PATH, fileName);
            }
        }
    }
}