﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace PMT.Utils
{
    public class AuthenticateUtil
    {
        private static readonly string DOMAIN = ConfigurationManager.AppSettings["DomainName"];
        private static readonly string GROUP_NAME = ConfigurationManager.AppSettings["LocalUserGroupName"];

        public static bool IsDomainAuthenticated(string userName, string password, ref string ErrMsg)
        {
            try
            {
                using (var context = new PrincipalContext(ContextType.Domain, DOMAIN))
                {
                    using (UserPrincipal usr = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, userName))
                    {
                        if (usr != null)
                        {
                            if (context.ValidateCredentials(userName, password) == false)
                            {
                                ErrMsg = "AD account login fail";
                                return false;
                            }
                            else
                            {
                                if (usr.IsAccountLockedOut())
                                {
                                    ErrMsg = "Account is locked";
                                    return false;
                                }
                                else
                                {
                                    return true;
                                }
                            }
                        }
                        else
                        {
                            ErrMsg = userName + " is not exist";
                            return false;
                        }                   
                    }                    
                }
            }
            catch(Exception ex)
            {
                ErrMsg = ex.Message;
                return false;
            }
        }

        public static bool IsLocalAuthenticated(string userName)
        {
            List<string> memberList = GetAllNamesInGroup(GROUP_NAME);

            if (memberList == null)
            {
                return false;
            }

            return memberList.Contains(userName);
        }

        public static bool IsLocalAuthenticated(string userName, string password)
        {
            string domainPath = "LDAP://" + ConfigurationManager.AppSettings["DomainName"];
            DirectoryEntry entry = new DirectoryEntry(domainPath, userName, password);

            //entry.AuthenticationType = AuthenticationTypes.Secure;

            DirectorySearcher search = new DirectorySearcher(domainPath);

            search.Filter = "(SAMAccountName=" + userName + ")";

            try
            {
                SearchResult r = search.FindOne();
                //string email = r.Properties["mail"][0].ToString();

                return (r != null);
            }
            catch
            {
                return false;
            }
        }

        public static List<string> GetAllNamesInGroup(string groupName)
        {
            List<string> result = new List<string>();
            DirectoryEntry localMachine = new DirectoryEntry("WinNT://" + Environment.MachineName + ",Computer");
            DirectoryEntry admGroup = localMachine.Children.Find(groupName, "group");
            object members = admGroup.Invoke("members", null);

            foreach (object groupMember in (IEnumerable)members)
            {
                DirectoryEntry member = new DirectoryEntry(groupMember);

                result.Add(member.Name);
            }

            return result;
        }

        //public static string verifyNTuser(string domainName, string userName, string password)
        //{
        //    //DirectoryEntry dEntry = new DirectoryEntry("LDAP://ds.kycourts.net/CN=Users,DC=ds,DC=kycourts,DC=net");
        //    DirectoryEntry dEntry = new DirectoryEntry("LDAP://" + domainName, userName, password);

        //    DirectorySearcher dSearch = new DirectorySearcher(dEntry);
        //    dSearch.PageSize = 6000;
        //    dSearch.Filter = "cn=" + userName;
        //    dSearch.PropertiesToLoad.Add("cn");
        //    dSearch.PropertiesToLoad.Add("mail");
        //    dSearch.PropertiesToLoad.Add("objectSid");
        //    dSearch.CacheResults = true;
        //    if (dSearch.FindAll().Count > 0)
        //    {
        //        foreach (SearchResult sResultSet in dSearch.FindAll())
        //        {
        //            SecurityIdentifier sid = new SecurityIdentifier((byte[])sResultSet.Properties["objectSid"][0], 0);
        //            string[] namesid = sid.ToString().Split('-');
        //            dEntry.Close();
        //            return sResultSet.Properties["cn"][0].ToString() + ";" + sResultSet.Properties["mail"][0].ToString() + ";" +
        //                namesid[namesid.Length - 1].ToString();

        //        }

        //    }
        //    else
        //    {
        //        dEntry.Close();
        //        return "false";
        //    }

        //    return "false";
        //}
    }
}